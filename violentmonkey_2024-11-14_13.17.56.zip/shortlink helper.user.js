// ==UserScript==
// @name        shortlink helper
// @namespace   Violentmonkey Scripts
// @match       *://1advertisingexcel.com/*
// @match       *://techedifier.com/*
// @match       *://basketballsavvy.com/*
// @match       *://healthyfollicles.com/*
// @match       *://thefitbrit.co.uk/*
// @match       *://englishwritingsite.xyz/*
// @match       *://tunebug.com/*
// @match       *://boredboard.com/*
// @match       *://boardgamechick.com/*

// @match       *://hauntingrealm.com/*
// @match       *://vegan4k.com/*
// @match       *://pluginmixer.com/*
// @match       *://gametechreviewer.com/*
// @match       *://chefknives.expert/*
// @match       *://misterio.ro/*
// @match       *://vrtier.com/*
// @match       *://substitutefor.com/*
// @match       *://earnfromyourlaptop.com/*

// @match       *://appetizingeat.com/*
// @match       *://shinchu.net/*
// @match       *://allcryptoz.net/*
// @match       *://gearsadviser.com/*
// @match       *:///*
// @match       *:///*

// @grant       none
// @version     2.1
// @author      sABER (juansi)
// @description Script de uso personal, adicional para pasar acortadores. Contribuciones via FaucetPay User: Crypto4Script. Try to take over the world!
// @run-at      document-start
// ==/UserScript==

(function() { 'use strict';

function getElement(selector) {
  return document.querySelector(selector);
}

function existElement(selector) {
  return getElement(selector) !== null;
}

function formSubmit(selector, time) {
  let elem = (typeof selector === 'string') ? getElement(selector).closest('form') : selector;
  window.setTimeout(()=>{
    elem.submit();
  }, time * 1000);
}

function setCaptchaVisible(captcha){
  var $div = $(captcha).parents('div');
  for (var i = 0; i<$div.length; i++){
    if ($div[i].style.display === 'none') {
      $div[i].style.display = 'block';
    }
  }
}

function iconCaptcha(selector){
  let t = setInterval(()=>{
    setCaptchaVisible('.iconcaptcha-modal');
    let f = getElement(".iconcaptcha-holder.iconcaptcha-theme-light.iconcaptcha-success");
    if (f) { formSubmit(selector, 1);
            clearInterval(t);
           }
  }, 3000);
}

function changeTitle(text){
  document.title = text;
  window.setTimeout(()=>{
    changeTitle(text.substr(1) + text.substr(0, 1));
  }, 200);
}

function invoke(selector, time){
  if (document.getElementsByClassName('g-recaptcha').length !==0) {
    changeTitle(' Solve reCaptcha ');
    let c = document.getElementsByClassName('g-recaptcha')[0].closest('form');
    let t = window.setInterval(()=> {
      if (window.grecaptcha.getResponse().length !==0) {
        formSubmit(c, 1);
        clearInterval(t);
      }
    }, 1000);
  }
  else if (existElement('input[name=_iconcaptcha-token]')) {
    changeTitle(' Solve iconCaptcha ');
    iconCaptcha(selector);
  }
  else {
    formSubmit(selector, time);
  }
}

function disable_timers(string2find, nameFunc){
  var target = window[nameFunc];
  window[nameFunc] = function(...args){
    const stringFunc = String(args);
    if ((new RegExp(string2find)).test(stringFunc)) args[0] = function(){};
    return target.call(this, ...args);
  }
}

function getForm(familyName){
  var forms = document.forms;
  for (var i = 0; i < forms.length; i++) {
    if (familyName === 'clks'){
      var form = forms[i].id;
      if (form.includes('blogger')) continue;
      return forms[i];
      }
    else if (familyName === 'random') {
      var bait = forms[i].action;
      if (/bypass.html|adblock.html/.test(bait)) continue;
      return forms[i];
    }
    else {
      return;
    }
  }
}

Object.defineProperty(document, 'querySelector', { value: document.querySelector, configurable: false, writable: false });
Object.defineProperty(HTMLFormElement.prototype, 'submit', { writable: false });
disable_timers('(/ad-now.php|/bypass|Solve|/bypass.php reCaptcha)', 'setInterval');
disable_timers('(bl0ck3d|Solve reCaptcha)', 'setTimeout');


             var l = new URL(window.location.href);
                switch (l.hostname) {
                  case 'blog.cryptowidgets.net': case 'blog.insurancegold.in': case 'blog.wiki-topia.com':
                  case 'blog.freeoseocheck.com': case 'blog.coinsvalue.net': case 'blog.cookinguide.net':
                  case 'blog.makeupguide.net': case 'blog.carstopia.net': case 'blog.carsmania.net':
                    document.addEventListener('DOMContentLoaded', function() {
                      document.querySelectorAll('.row.text-center').forEach((dtc) => dtc.parentNode.removeChild(dtc));
                      invoke('#countdown', 20);
                    });
                    break;
                  case '1advertisingexcel.com':
                    document.addEventListener('DOMContentLoaded', function() {
                      invoke(getForm('random'), );
                    });
                    break;
                  case 'techedifier.com': case 'basketballsavvy.com': case 'healthyfollicles.com':
                  case 'thefitbrit.co.uk': case 'englishwritingsite.xyz': case 'tunebug.com':
                  case 'boredboard.com': case 'boardgamechick.com': case 'hauntingrealm.com':
                  case 'substitutefor.com': case 'allcryptoz.net': case 'gearsadviser.com':
                  case 'earnfromyourlaptop.com': case 'appetizingeat.com': case 'shinchu.net':
                  case '': case '': case '':
                    document.addEventListener('DOMContentLoaded', function() {
                      invoke(getForm('random'), 16);
                    });
                    break;
                  case 'vegan4k.com': case 'pluginmixer.com': case 'gametechreviewer.com':
                  case 'chefknives.expert': case 'misterio.ro': case 'vrtier.com':
                    document.addEventListener('DOMContentLoaded', function() {
                      invoke(getForm('random'), 16);
                    });
                    break;
                  default:
                    break;
                }
            })();